from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q 
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.models import User
from decimal import Decimal # 👈 لضمان دقة حساب العملة
from datetime import date, timedelta 

# موديلات التطبيق الحالي
from .models import Product, Review, Order, OrderItem, Cart, CartItem 
# موديلات التطبيقات الخارجية
from eagle_server.models import ServerPlan, ServerNews 


# ===============================================
# 🛑 1. الدوال المساعدة (Helper Functions)
# ===============================================

def _cart_id(request):
    """جلب أو إنشاء رقم تعريفي للجلسة (Session ID) للزائر"""
    cart = request.session.session_key
    if not cart:
        cart = request.session.create()
    return cart

def get_user_cart_items(request):
    """دالة موحدة لجلب عناصر السلة للمستخدم المسجل أو الزائر"""
    if request.user.is_authenticated:
        return CartItem.objects.filter(user=request.user, is_active=True)
    else:
        try:
            cart = Cart.objects.get(cart_id=_cart_id(request))
            return CartItem.objects.filter(cart=cart, is_active=True)
        except (Cart.DoesNotExist, ObjectDoesNotExist):
            return CartItem.objects.none()

# ===============================================
# 2. دوال الصفحات الأساسية
# ===============================================

def home_view(request):
    return render(request, 'index.html')

def store_view(request):
    products = Product.objects.all()
    return render(request, 'store.html', {'products': products})

def server_view(request):
    iptv_plans = ServerPlan.objects.filter(server_type='iptv')
    cccam_plans = ServerPlan.objects.filter(server_type='cccam')
    latest_news = ServerNews.objects.all().order_by('-date_posted')
    
    return render(request, 'server.html', {
        'iptv_plans': iptv_plans,
        'cccam_plans': cccam_plans,
        'news_list': latest_news 
    })

def product_details(request, id):
    product = get_object_or_404(Product, id=id)
    return render(request, 'product_details.html', {'product': product})


# ===============================================
# 3. دوال السلة (Cart Logic)
# ===============================================

def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    current_user = request.user
    
    if current_user.is_authenticated:
        try:
            cart_item = CartItem.objects.get(product=product, user=current_user)
            cart_item.quantity += 1
            cart_item.save()
        except CartItem.DoesNotExist:
            CartItem.objects.create(product=product, quantity=1, user=current_user)
            
    else:
        try:
            cart = Cart.objects.get(cart_id=_cart_id(request)) 
        except Cart.DoesNotExist:
            cart = Cart.objects.create(cart_id=_cart_id(request))
            
        try:
            cart_item = CartItem.objects.get(product=product, cart=cart)
            cart_item.quantity += 1
            cart_item.save()
        except CartItem.DoesNotExist:
            CartItem.objects.create(product=product, quantity=1, cart=cart)
            
    messages.success(request, f"{product.name} تمت إضافته للسلة!")
    return redirect('cart')



# في ملف store/views.py

# ... (بعد دالة add_to_cart) ...

def increase_quantity(request, product_id):
    """زيادة كمية المنتج في السلة بمقدار 1"""
    
    # 1. تحديد شروط البحث: المستخدم الحالي أو معرف الجلسة
    if request.user.is_authenticated:
        query_filter = Q(user=request.user, product_id=product_id)
    else:
        try:
            cart = Cart.objects.get(cart_id=_cart_id(request))
            query_filter = Q(cart=cart, product_id=product_id)
        except Cart.DoesNotExist:
            return redirect('cart')

    try:
        cart_item = CartItem.objects.get(query_filter)
        cart_item.quantity += 1
        cart_item.save()
    except CartItem.DoesNotExist:
        # إذا لم يتم العثور عليه، نعود للصفحة الرئيسية
        pass
        
    return redirect('cart')


def decrease_quantity(request, product_id):
    """إنقاص كمية المنتج في السلة، وإذا وصلت للصفر يتم حذفه"""

    # 1. تحديد شروط البحث: المستخدم الحالي أو معرف الجلسة
    if request.user.is_authenticated:
        query_filter = Q(user=request.user, product_id=product_id)
    else:
        try:
            cart = Cart.objects.get(cart_id=_cart_id(request))
            query_filter = Q(cart=cart, product_id=product_id)
        except Cart.DoesNotExist:
            return redirect('cart')
            
    try:
        cart_item = CartItem.objects.get(query_filter)
        
        if cart_item.quantity > 1:
            cart_item.quantity -= 1
            cart_item.save()
        else:
            # إذا كانت الكمية 1 أو أقل، نقوم بحذف المنتج من السلة بالكامل
            cart_item.delete()
            
    except CartItem.DoesNotExist:
        # إذا لم يتم العثور عليه، نعود للصفحة الرئيسية
        pass
        
    return redirect('cart')

# ... (قبل دالة remove_from_cart) ...

def remove_from_cart(request, product_id):
    if request.user.is_authenticated:
        CartItem.objects.filter(product_id=product_id, user=request.user).delete()
    else:
        try:
            cart = Cart.objects.get(cart_id=_cart_id(request))
            CartItem.objects.filter(product_id=product_id, cart=cart).delete()
        except Cart.DoesNotExist:
            pass
            
    messages.info(request, "تم حذف المنتج من السلة.")
    return redirect('cart')

def cart_view(request):
    cart_items = get_user_cart_items(request)
    
    total = Decimal('0.00')
    total_shipping = Decimal('0.00')
    
    for cart_item in cart_items:
        price = Decimal(cart_item.product.price) 
        shipping = Decimal(cart_item.product.shipping_fee)
        
        total += price * cart_item.quantity
        total_shipping += shipping * cart_item.quantity
    
    tax = Decimal('0.00') # إلغاء الضريبة
    grand_total = total + total_shipping + tax 

    context = {
        'cart_items': cart_items,
        'subtotal': total,
        'shipping_fee': total_shipping,
        'tax': tax,
        'grand_total': grand_total,
    }
    return render(request, 'cart.html', context)


# ===============================================
# 4. دوال الدفع والـ Checkout (المنطق الحاسم)
# ===============================================

def checkout(request):
    cart_items = get_user_cart_items(request)
    
    # 1. التحقق إن السلة مش فاضية
    if not cart_items or len(cart_items) == 0:
        messages.warning(request, "السلة فارغة يا صديقي! ضيف منتجات الأول 🛒")
        return redirect('store')

    # 2. حساب المجاميع (Total, Shipping, Tax)
    total = sum(Decimal(item.product.price) * item.quantity for item in cart_items)
    shipping_fee = sum(Decimal(item.product.shipping_fee) * item.quantity for item in cart_items)
    tax = Decimal('0.00')
    grand_total = total + shipping_fee + tax

    # 🛑 3. معالجة زر "تأكيد الطلب" (POST Request)
    if request.method == 'POST':
        if not request.user.is_authenticated:
            messages.error(request, "يجب تسجيل الدخول لإتمام الطلب.")
            return redirect('login')
            
        # استلام البيانات
        full_name = request.POST.get('full_name')
        phone = request.POST.get('phone')
        address_input = request.POST.get('address') # تم تعديل الاسم
        city = request.POST.get('city')
        payment_method = request.POST.get('payment_method')
        payment_screenshot = request.FILES.get('receiptImage')

        try:
            # إنشاء وحفظ الطلب الرئيسي (Order)
            new_order = Order.objects.create(
                user=request.user,
                full_name=full_name,
                phone_number=phone,
                # ندمج المدينة والعنوان معًا لحقل العنوان
                address=f"{city} - {address_input}", 
                total_price=grand_total,
                payment_method=payment_method,
                payment_screenshot=payment_screenshot,
                ip_address=request.META.get('REMOTE_ADDR')
            )

            # نقل المنتجات وحفظها في OrderItems
            for item in cart_items:
                OrderItem.objects.create(
                    order=new_order,
                    product=item.product,
                    quantity=item.quantity,
                    product_price=item.product.price,
                    user=request.user
                )

            # تنظيف السلة ومسح المنتجات من الداتابيز
            cart_items.delete()

            messages.success(request, "تم استلام طلبك بنجاح! سيتم مراجعته قريباً.")
            return redirect('profile')

        except Exception as e:
            # 🚨🚨 هذا الجزء سيكشف سبب فشل الحفظ في الداتابيز 🚨🚨
            print(f"❌ خطأ قاتل عند حفظ الطلب: {e}")
            messages.error(request, f"حدث خطأ أثناء حفظ الطلب. (السبب: {e})")
            return redirect('checkout')

    # 4. عرض الصفحة (GET Request)
    context = {
        'cart_items': cart_items,
        'total': total,
        'shipping_fee': shipping_fee,
        'tax': tax,
        'grand_total': grand_total,
    }
    return render(request, 'checkout.html', context)


# ===============================================
# 5. دوال المصادقة والبروفايل والتقييم والبحث
# ===============================================

def signup_view(request):
    if request.method == 'POST':
        # ... (Signup logic goes here) ...
        pass
    return render(request, 'register.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        pass_word = request.POST.get('password')
        
        user = authenticate(request, username=username, password=pass_word)
        
        if user is not None:
            login(request, user) 
            messages.success(request, f"مرحباً بك مجدداً يا {username}!") 
            return redirect('home') 
        else:
            messages.error(request, "اسم المستخدم أو كلمة المرور خطأ ❌") 
            
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('home')

@login_required(login_url='login')
def profile_view(request):
    user_orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'profile.html', {'orders': user_orders})

@login_required(login_url='login')
def add_review(request, product_id):
    if request.method == 'POST':
        product = get_object_or_404(Product, id=product_id)
        
        rating_value = request.POST.get('rating')
        comment_text = request.POST.get('comment')
        
        if Review.objects.filter(user=request.user, product=product).exists():
            messages.error(request, "لقد قمت بتقييم هذا المنتج بالفعل.")
            return redirect('product_details', id=product_id)

        Review.objects.create(
            user=request.user,
            product=product,
            rating=int(rating_value),
            comment=comment_text,
        )
        messages.success(request, "تم إضافة تقييمك بنجاح! شكراً لك.")
    
    return redirect('product_details', id=product_id)

def about_us_view(request):
    return redirect('home') 

def contact_us_view(request):
    return redirect('home') 

# ===============================================
# 5. دالة البحث (Search Logic)
# ===============================================

def search_view(request):
    query = request.GET.get('q', '').strip()
    
    products = []
    iptv_plans = []
    cccam_plans = []

    if query:
        # القاموس الموسع لترجمة الكلمات العربية لأكواد الداتابيز
        keyword_map = {
            'رسيفر': 'receiver', 'ريسيفر': 'receiver', 'رسيفير': 'receiver', 'ريسفير': 'receiver', 'رسفر': 'receiver', 'جهاز': 'receiver',
            'عدس': 'lnb', 'قطعة': 'lnb', 'لاقط': 'lnb', 'طبق': 'lnb', 'اطباق': 'lnb', 'دش': 'lnb',
            'كابل': 'cable', 'سلك': 'cable', 'وصل': 'cable', 'hdmi': 'cable', 'usb': 'cable',
            'ريموت': 'remote', 'رموت': 'remote', 'تحكم': 'remote',
            'صيان': 'maintenance', 'اكسسوار': 'accessories', 'تركيب': 'tools', 'ادوات': 'tools',
            'iptv': 'iptv', 'cccam': 'cccam', 'شير': 'cccam', 'شيرينج': 'cccam',
        }

        target_codes = []
        for word, code in keyword_map.items():
            if word in query.lower():
                target_codes.append(code)

        # 1. البحث في المنتجات
        products = Product.objects.filter(
            Q(name__icontains=query) | Q(description__icontains=query) |
            Q(category__icontains=query) |
            Q(category__in=target_codes) 
        ).distinct()

        # 2. البحث في السيرفرات
        all_plans = ServerPlan.objects.filter(
            Q(name__icontains=query) | Q(features__icontains=query) |
            Q(server_type__icontains=query)
        ).distinct()

        iptv_plans = all_plans.filter(server_type='iptv')
        cccam_plans = all_plans.filter(server_type='cccam')
    
    context = {
        'query': query,
        'products': products,
        'iptv_plans': iptv_plans,
        'cccam_plans': cccam_plans,
    }
    
    return render(request, 'search_results.html', context)